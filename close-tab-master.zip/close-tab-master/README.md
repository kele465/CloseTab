# CloseTab

#### 介绍

浏览器插件，支持一键关闭当前窗口所有 tab 页并保存，支持一键恢复关闭的标签页

#### 软件架构

软件架构说明

#### 安装教程

1.  下载 ZIP 压缩包 到本地
2.  解压文件，打开浏览器扩展程序界面，拖拽到页面添加，或者点击加载已解压的扩展程序

#### 使用说明

1.  ![示例 1](https://i.imgur.com/nBgzLe8.jpeg '示例 1')

2.  ![示例 2](https://i.imgur.com/SabhWW7.png '示例 2')

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request

#### 特技

1.  使用 Readme_XXX.md 来支持不同的语言，例如 Readme_en.md, Readme_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
