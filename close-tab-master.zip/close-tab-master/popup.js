let currentTab = 'recent';

document.addEventListener('DOMContentLoaded', () => {
  const openNewTabCheckbox = document.getElementById('openNewTab');
  const closeTabsAfterSaveCheckbox =
    document.getElementById('closeTabsAfterSave');
  const recentTabButton = document.getElementById('recentTab');
  const favoriteTabButton = document.getElementById('favoriteTab');
  const openPageTypeRadios = document.getElementsByName('openPageType');

  // 加载保存的设置
  chrome.storage.local.get(
    ['openNewTab', 'closeTabsAfterSave', 'openPageType'],
    (result) => {
      openNewTabCheckbox.checked = result.openNewTab !== false;
      closeTabsAfterSaveCheckbox.checked = result.closeTabsAfterSave !== false;
      const openPageType = result.openPageType || 'blank';
      openPageTypeRadios.forEach((radio) => {
        radio.checked = radio.value === openPageType;
      });
    },
  );

  // 保存设置
  openNewTabCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ openNewTab: openNewTabCheckbox.checked });
  });

  closeTabsAfterSaveCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({
      closeTabsAfterSave: closeTabsAfterSaveCheckbox.checked,
    });
  });

  // 保存页面类型设置
  openPageTypeRadios.forEach((radio) => {
    radio.addEventListener('change', () => {
      if (radio.checked) {
        chrome.storage.local.set({ openPageType: radio.value });
      }
    });
  });

  // 标签页切换事件
  recentTabButton.addEventListener('click', () => {
    currentTab = 'recent';
    recentTabButton.classList.add('active');
    favoriteTabButton.classList.remove('active');
    showTabGroups();
  });

  favoriteTabButton.addEventListener('click', () => {
    currentTab = 'favorite';
    favoriteTabButton.classList.add('active');
    recentTabButton.classList.remove('active');
    showTabGroups();
  });

  // 添加事件委托处理标签组和标签页的按钮点击
  document.getElementById('tabGroups').addEventListener('click', async (e) => {
    const target = e.target;
    const button = target.closest('button');
    if (!button) return;

    if (button.matches('.restore-group-btn')) {
      const groupId = button.dataset.groupId;
      await restoreTabGroup(groupId);
    } else if (button.matches('.delete-group-btn')) {
      const groupId = button.dataset.groupId;
      await deleteTabGroup(groupId);
    } else if (button.matches('.open-tab-btn')) {
      const groupId = button.closest('.tab-group').dataset.groupId;
      const tabIndex = parseInt(button.dataset.tabIndex);
      await openSingleTab(groupId, tabIndex);
    } else if (button.matches('.delete-tab-btn')) {
      const groupId = button.closest('.tab-group').dataset.groupId;
      const tabIndex = parseInt(button.dataset.tabIndex);
      await deleteTabFromGroup(groupId, tabIndex);
    } else if (button.matches('.favorite-btn')) {
      const groupId = button.closest('.tab-group').dataset.groupId;
      await toggleFavorite(groupId);
    }
  });

  // 切换收藏状态
  async function toggleFavorite(groupId) {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const groupIndex = tabGroups.findIndex((g) => g.id === Number(groupId));

      if (groupIndex === -1) return;

      tabGroups[groupIndex].favorite = !tabGroups[groupIndex].favorite;
      await chrome.storage.local.set({ tabGroups });
      showTabGroups();
    } catch (error) {
      console.error('切换收藏状态时出错：', error);
    }
  }

  const closeAndSaveButton = document.getElementById('closeAndSave');

  // 关闭并保存标签页
  closeAndSaveButton.addEventListener('click', async () => {
    try {
      // 获取当前窗口除新标签页外的所有标签页
      const tabs = await chrome.tabs.query({ currentWindow: true });

      // 保存标签组信息
      const tabGroup = {
        id: Date.now(),
        name: new Date().toLocaleString(),
        tabs: tabs.map((tab) => ({
          url: tab.url,
          title: tab.title,
          favIconUrl: tab.favIconUrl || '',
        })),
        favorite: false,
      };

      // 从存储中获取现有的标签组
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');

      // 添加新的标签组
      tabGroups.unshift(tabGroup);

      // 保存更新后的标签组
      await chrome.storage.local.set({ tabGroups });

      // 获取设置
      const { openNewTab, closeTabsAfterSave, openPageType } =
        await chrome.storage.local.get([
          'openNewTab',
          'closeTabsAfterSave',
          'openPageType',
        ]);

      // 如果需要关闭标签页
      if (closeTabsAfterSave !== false) {
        await Promise.all(
          tabs.map((tab) => {
            chrome.tabs.remove(tab.id);
          }),
        );
      }

      // 如果需要打开新标签页
      if (openNewTab !== false) {
        if (openPageType === 'manager') {
          await chrome.tabs.create({ url: 'manager.html' });
        } else {
          await chrome.windows.create({ focused: true });
        }
      }

      // 等待窗口创建完成
      await new Promise((resolve) => setTimeout(resolve, 500));

      // 刷新标签组列表
      showTabGroups();
    } catch (error) {
      console.error('关闭并保存标签页时出错：', error);
    }
  });

  // 初始化时显示标签组列表
  showTabGroups();
});

// 显示保存的标签组
async function showTabGroups() {
  try {
    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const tabGroupsContainer = document.getElementById('tabGroups');
    const filteredGroups =
      currentTab === 'favorite'
        ? tabGroups.filter((group) => group.favorite)
        : tabGroups;

    tabGroupsContainer.innerHTML = filteredGroups
      .map(
        (group) => `
      <div class="tab-group" data-group-id="${group.id}">
        <div class="tab-group-header">
          <div>
            <h4 class="tab-group-title">${group.name}</h4>
            <span class="tab-count">${group.tabs.length} 个标签页</span>
          </div>
          <div class="tab-group-actions">
            <button class="favorite-btn icon-btn ${
              group.favorite ? 'active' : ''
            }" data-group-id="${group.id}">
              <img src="images/icons/star.svg" alt="收藏" class="icon">
            </button>
            <button class="restore-group-btn small" data-group-id="${
              group.id
            }">恢复</button>
            <button class="delete-group-btn small danger" data-group-id="${
              group.id
            }">删除</button>
          </div>
        </div>
        <div class="tab-list">
          ${group.tabs
            .map(
              (tab, index) => `
            <div class="tab-item">
              <img src="${
                tab.favIconUrl || 'images/icon16.png'
              }" alt="" style="width: 16px; height: 16px; margin-right: 8px;">
              <span class="tab-title">${tab.title}</span>
              <div class="tab-actions">
                <button class="open-tab-btn icon-btn" data-tab-index="${index}">
                  <img src="images/icons/visit.svg" alt="打开" class="icon">
                </button>
                <button class="delete-tab-btn icon-btn danger" data-tab-index="${index}">
                  <img src="images/icons/trash.svg" alt="删除" class="icon">
                </button>
              </div>
            </div>
          `,
            )
            .join('')}
        </div>
      </div>
    `,
      )
      .join('');
  } catch (error) {
    console.error('显示标签组时出错：', error);
  }
}

// 恢复标签组
async function restoreTabGroup(groupId) {
  try {
    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const group = tabGroups.find((g) => g.id === Number(groupId));

    if (!group) {
      console.error('未找到标签组：', groupId);
      return;
    }

    // 创建新窗口
    const window = await chrome.windows.create({ focused: true });

    // 等待窗口创建完成
    await new Promise((resolve) => setTimeout(resolve, 500));

    // 获取新窗口中的空白标签页
    const [emptyTab] = await chrome.tabs.query({ windowId: window.id });

    // 批量创建标签页
    const createTabPromises = group.tabs.map((tab) =>
      chrome.tabs.create({
        windowId: window.id,
        url: tab.url,
        active: false,
      }),
    );

    await Promise.all(createTabPromises);

    // 关闭空白标签页
    if (emptyTab) {
      await chrome.tabs.remove(emptyTab.id);
    }
  } catch (error) {
    console.error('恢复标签组时出错：', error);
  }
}

// 打开单个标签页
async function openSingleTab(groupId, tabIndex) {
  try {
    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const group = tabGroups.find((g) => g.id === Number(groupId));

    if (!group || !group.tabs[tabIndex]) {
      console.error('未找到标签页');
      return;
    }

    const tab = group.tabs[tabIndex];

    // 检查是否存在相同URL的标签页
    const existingTabs = await chrome.tabs.query({ url: tab.url });
    if (existingTabs.length > 0) {
      // 如果存在，聚焦到第一个匹配的标签页
      await chrome.tabs.update(existingTabs[0].id, { active: true });
      await chrome.windows.update(existingTabs[0].windowId, { focused: true });
    } else {
      // 如果不存在，创建新标签页
      await chrome.tabs.create({ url: tab.url });
    }
  } catch (error) {
    console.error('打开标签页时出错：', error);
  }
}

// 从标签组中删除单个标签页
async function deleteTabFromGroup(groupId, tabIndex) {
  try {
    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const groupIndex = tabGroups.findIndex((g) => g.id === Number(groupId));

    if (groupIndex === -1) {
      console.error('未找到标签组');
      return;
    }

    const group = tabGroups[groupIndex];
    group.tabs.splice(tabIndex, 1);

    // 如果标签组中没有标签页了，删除整个标签组
    if (group.tabs.length === 0) {
      tabGroups.splice(groupIndex, 1);
    }

    await chrome.storage.local.set({ tabGroups });
    await showTabGroups(); // 刷新显示
  } catch (error) {
    console.error('删除标签页时出错：', error);
  }
}

// 删除标签组
async function deleteTabGroup(groupId) {
  try {
    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const updatedGroups = tabGroups.filter((g) => g.id !== Number(groupId));
    await chrome.storage.local.set({ tabGroups: updatedGroups });

    // 刷新显示
    const tabGroupsContainer = document.getElementById('tabGroups');
    const groupElement = tabGroupsContainer.querySelector(
      `[data-group-id="${groupId}"]`,
    );
    if (groupElement) {
      groupElement.remove();
    }
  } catch (error) {
    console.error('删除标签组时出错：', error);
  }
}
