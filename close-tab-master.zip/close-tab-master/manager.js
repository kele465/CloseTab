document.addEventListener('DOMContentLoaded', async () => {
  const searchInput = document.getElementById('searchInput');
  const sortSelect = document.getElementById('sortSelect');
  const selectAllBtn = document.getElementById('selectAllBtn');
  const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
  const mergeSelectedBtn = document.getElementById('mergeSelectedBtn');
  const exportSelectedBtn = document.getElementById('exportSelectedBtn');
  const importFileInput = document.getElementById('importFileInput');
  const importBtn = document.createElement('button');
  importBtn.className = 'primary-btn';
  importBtn.textContent = '导入';
  importBtn.onclick = () => importFileInput.click();
  exportSelectedBtn.parentNode.insertBefore(importBtn, importFileInput);
  let selectedGroups = new Set();

  // 加载并显示标签组
  async function loadTabGroups() {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      return tabGroups;
    } catch (error) {
      console.error('加载标签组时出错：', error);
      return [];
    }
  }

  // 搜索和排序标签组
  function filterAndSortTabGroups(tabGroups, searchText, sortType) {
    let filtered = tabGroups;

    // 收藏过滤
    const favoriteFilter = document.getElementById('favoriteFilter');
    if (favoriteFilter && favoriteFilter.checked) {
      filtered = filtered.filter(group => group.favorite);
    }

    // 搜索过滤
    if (searchText) {
      const lowerSearchText = searchText.toLowerCase();
      filtered = filtered.filter((group) => {
        const matchInTitle = group.name.toLowerCase().includes(lowerSearchText);
        const matchInTabs = group.tabs.some(
          (tab) =>
            tab.title.toLowerCase().includes(lowerSearchText) ||
            tab.url.toLowerCase().includes(lowerSearchText),
        );
        return matchInTitle || matchInTabs;
      });
    }

    // 排序
    return filtered.sort((a, b) => {
      switch (sortType) {
        case 'time-desc':
          return b.id - a.id;
        case 'time-asc':
          return a.id - b.id;
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'name-desc':
          return b.name.localeCompare(a.name);
        case 'tabs-desc':
          return b.tabs.length - a.tabs.length;
        case 'tabs-asc':
          return a.tabs.length - b.tabs.length;
        default:
          return 0;
      }
    });
  }

  // 渲染标签组列表
  function renderTabGroups(groups) {
    const tabGroupsContainer = document.getElementById('tabGroups');
    tabGroupsContainer.innerHTML = groups
      .map(
        (group) => `
        <div class="tab-group ${
          selectedGroups.has(group.id) ? 'selected' : ''
        }" data-group-id="${group.id}">
          <div class="tab-group-header">
            <div>
              <h3 class="tab-group-title">${group.name}</h3>
              <span class="tab-count">${group.tabs.length} 个标签页</span>
            </div>
            <div class="tab-group-actions">
              <button class="favorite-btn icon-btn ${
                group.favorite ? 'active' : ''
              }" data-group-id="${group.id}">
                <img src="images/icons/star.svg" alt="收藏" class="icon">
              </button>
              <button class="restore-group-btn primary-btn" data-group-id="${
                group.id
              }">恢复</button>
              <button class="delete-group-btn danger-btn" data-group-id="${
                group.id
              }">删除</button>
            </div>
          </div>
          <div class="tab-list">
            ${group.tabs
              .map(
                (tab, index) => `
              <div class="tab-item">
                <img src="${
                  tab.favIconUrl || 'images/icon16.png'
                }" alt="" style="width: 16px; height: 16px;">
                <span class="tab-title">${tab.title}</span>
                <div class="tab-actions">
                  <button class="open-tab-btn icon-btn" data-group-id="${
                    group.id
                  }" data-tab-index="${index}">
                    <img src="images/icons/visit.svg" alt="打开" class="icon">
                  </button>
                  <button class="delete-tab-btn icon-btn danger" data-group-id="${
                    group.id
                  }" data-tab-index="${index}">
                    <img src="images/icons/trash.svg" alt="删除" class="icon">
                  </button>
                </div>
              </div>
            `,
              )
              .join('')}
          </div>
        </div>
      `,
      )
      .join('');
  }

  // 更新标签组显示
  async function updateTabGroups() {
    const groups = await loadTabGroups();
    const filteredAndSorted = filterAndSortTabGroups(
      groups,
      searchInput.value,
      sortSelect.value,
    );
    renderTabGroups(filteredAndSorted);
  }

  // 搜索和排序事件处理
  searchInput.addEventListener('input', updateTabGroups);
  sortSelect.addEventListener('change', updateTabGroups);
  document.getElementById('favoriteFilter').addEventListener('change', updateTabGroups);

  // 批量操作事件处理
  selectAllBtn.addEventListener('click', async () => {
    const groups = await loadTabGroups();
    if (selectedGroups.size === groups.length) {
      selectedGroups.clear();
    } else {
      selectedGroups = new Set(groups.map((g) => g.id));
    }
    updateTabGroups();
  });

  deleteSelectedBtn.addEventListener('click', async () => {
    if (selectedGroups.size === 0) return;
    if (!confirm(`确定要删除选中的 ${selectedGroups.size} 个标签组吗？`))
      return;

    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const updatedGroups = tabGroups.filter((g) => !selectedGroups.has(g.id));
    await chrome.storage.local.set({ tabGroups: updatedGroups });
    selectedGroups.clear();
    updateTabGroups();
  });

  mergeSelectedBtn.addEventListener('click', async () => {
    if (selectedGroups.size < 2) {
      alert('请至少选择两个标签组进行合并');
      return;
    }

    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const selectedGroupsData = tabGroups.filter((g) =>
      selectedGroups.has(g.id),
    );

    // 创建新的合并标签组
    const mergedGroup = {
      id: Date.now(),
      name: `合并的标签组 (${new Date().toLocaleString()})`,
      tabs: selectedGroupsData.flatMap((g) => g.tabs),
      favorite: false,
    };

    // 更新存储
    const updatedGroups = [
      mergedGroup,
      ...tabGroups.filter((g) => !selectedGroups.has(g.id)),
    ];
    await chrome.storage.local.set({ tabGroups: updatedGroups });
    selectedGroups.clear();
    updateTabGroups();
  });

  exportSelectedBtn.addEventListener('click', async () => {
    if (selectedGroups.size === 0) return;

    const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
    const selectedGroupsData = tabGroups.filter((g) =>
      selectedGroups.has(g.id),
    );
    const exportData = JSON.stringify(selectedGroupsData, null, 2);

    // 创建下载链接
    const blob = new Blob([exportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tab_groups_${new Date().toISOString()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  // 标签组点击事件处理
  document.getElementById('tabGroups').addEventListener('click', async (e) => {
    const target = e.target;
    const tabGroup = target.closest('.tab-group');
    if (!tabGroup) return;

    const groupId = Number(tabGroup.dataset.groupId);
    const button = target.closest('button');

    if (!button) {
      // 切换选中状态
      if (selectedGroups.has(groupId)) {
        selectedGroups.delete(groupId);
      } else {
        selectedGroups.add(groupId);
      }
      updateTabGroups();
      return;
    }

    if (button.matches('.restore-group-btn')) {
      await restoreTabGroup(groupId);
    } else if (button.matches('.delete-group-btn')) {
      await deleteTabGroup(groupId);
    } else if (button.matches('.open-tab-btn')) {
      const tabIndex = parseInt(button.dataset.tabIndex);
      await openSingleTab(groupId, tabIndex);
    } else if (button.matches('.delete-tab-btn')) {
      const tabIndex = parseInt(button.dataset.tabIndex);
      await deleteTabFromGroup(groupId, tabIndex);
    } else if (button.matches('.favorite-btn')) {
      await toggleFavorite(groupId);
    }
  });

  // 恢复标签组
  async function restoreTabGroup(groupId) {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const group = tabGroups.find((g) => g.id === groupId);

      if (!group) return;

      const window = await chrome.windows.create({ focused: true });
      await new Promise((resolve) => setTimeout(resolve, 500));
      const [emptyTab] = await chrome.tabs.query({ windowId: window.id });

      await Promise.all(
        group.tabs.map((tab) =>
          chrome.tabs.create({
            windowId: window.id,
            url: tab.url,
            active: false,
          }),
        ),
      );

      if (emptyTab) {
        await chrome.tabs.remove(emptyTab.id);
      }
    } catch (error) {
      console.error('恢复标签组时出错：', error);
    }
  }

  // 打开单个标签页
  async function openSingleTab(groupId, tabIndex) {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const group = tabGroups.find((g) => g.id === groupId);

      if (!group || !group.tabs[tabIndex]) return;

      const tab = group.tabs[tabIndex];
      const existingTabs = await chrome.tabs.query({ url: tab.url });

      if (existingTabs.length > 0) {
        await chrome.tabs.update(existingTabs[0].id, { active: true });
        await chrome.windows.update(existingTabs[0].windowId, {
          focused: true,
        });
      } else {
        await chrome.tabs.create({ url: tab.url });
      }
    } catch (error) {
      console.error('打开标签页时出错：', error);
    }
  }

  // 从标签组中删除标签页
  async function deleteTabFromGroup(groupId, tabIndex) {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const groupIndex = tabGroups.findIndex((g) => g.id === groupId);

      if (groupIndex === -1) return;

      const group = tabGroups[groupIndex];
      group.tabs.splice(tabIndex, 1);

      if (group.tabs.length === 0) {
        tabGroups.splice(groupIndex, 1);
      }

      await chrome.storage.local.set({ tabGroups });
      updateTabGroups();
    } catch (error) {
      console.error('删除标签页时出错：', error);
    }
  }

  // 删除标签组
  async function deleteTabGroup(groupId) {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const updatedGroups = tabGroups.filter((g) => g.id !== groupId);
      await chrome.storage.local.set({ tabGroups: updatedGroups });
      updateTabGroups();
    } catch (error) {
      console.error('删除标签组时出错：', error);
    }
  }

  // 切换收藏状态
  async function toggleFavorite(groupId) {
    try {
      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const groupIndex = tabGroups.findIndex((g) => g.id === groupId);

      if (groupIndex === -1) return;

      tabGroups[groupIndex].favorite = !tabGroups[groupIndex].favorite;
      await chrome.storage.local.set({ tabGroups });
      updateTabGroups();
    } catch (error) {
      console.error('切换收藏状态时出错：', error);
    }
  }

  // 导入标签组
  importFileInput.addEventListener('change', async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const content = await file.text();
      const importedGroups = JSON.parse(content);

      if (!Array.isArray(importedGroups)) {
        alert('导入的文件格式不正确');
        return;
      }

      const { tabGroups = [] } = await chrome.storage.local.get('tabGroups');
      const updatedGroups = [...importedGroups, ...tabGroups];
      await chrome.storage.local.set({ tabGroups: updatedGroups });
      updateTabGroups();
      alert('导入成功');
    } catch (error) {
      console.error('导入标签组时出错：', error);
      alert('导入失败：' + error.message);
    }

    event.target.value = ''; // 重置文件输入
  });

  // 初始化显示
  updateTabGroups();
});
